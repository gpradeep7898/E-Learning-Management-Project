

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Course_View_Register
 */
@WebServlet("/Course_View_Register")
public class Course_View_Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Course_View_Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		String id=request.getParameter("id");
		String email=request.getParameter("email");
		String name=null,technology=null,fee=null,university=null,professor=null;
//		pw.println(email+" "+id);
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/amrutha","root","password-1");
			Statement stmt=conn.createStatement();
			ResultSet rs=stmt.executeQuery("select * from course");
			while(rs.next()){
				if(id.equalsIgnoreCase(rs.getString(2))){
					name=rs.getString(1);
					technology=rs.getString(3);
					fee=rs.getString(4);
					university=rs.getString(5);
					professor=rs.getString(6);
				}
			}
			PreparedStatement ps = conn.prepareStatement("insert into user_registered values(?,?,?,?,?,?,?)");
			ps.setString(1, email);
			ps.setString(2, name);
	        ps.setString(3, id);
	        ps.setString(4, university);
	        ps.setString(5, professor);
	        ps.setString(6, fee);
	        ps.setString(7, "No");
	        
	        ServletContext context=getServletContext();  
	        context.setAttribute("email",email);  
	        context.setAttribute("id", id);
	        int i = ps.executeUpdate();
	        if(i!=0){
	        	pw.println("Registered");
	        	response.sendRedirect("Proceed_Payment.jsp");
	        }else{
	        	pw.println("Not Registered");
//	        	response.sendRedirect("Admin_Not_Success.html");
	        }
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
